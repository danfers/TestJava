package br.com.cadastro_java;

// importa o JOptionPane
import javax.swing.JOptionPane;

// importa os pacotes
import br.com.cadastro_java.dao.*;
import br.com.cadastro_java.model.*;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// instancia os objetos
		Usuario usuario = new Usuario();
		UsuarioDAO cadastro = new UsuarioDAO();
		
		// input dos dados
		usuario.setNome(JOptionPane.showInputDialog("Informe o nome:"));
		usuario.setEmail(JOptionPane.showInputDialog("Informe o e-mail:"));
		
		// cadastra o usu�rio no banco
		cadastro.cadastrar(usuario);
		
		// informa o sucesso do cadastro
		JOptionPane.showMessageDialog(null, "Dados cadastrados com sucesso!");
		
		// encerra a aplica��o
		System.exit(0);
	}

}
