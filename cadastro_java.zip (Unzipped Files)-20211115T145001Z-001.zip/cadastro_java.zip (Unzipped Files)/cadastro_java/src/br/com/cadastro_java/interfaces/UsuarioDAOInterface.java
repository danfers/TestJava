package br.com.cadastro_java.interfaces;

// importa a classe Usuario
import br.com.cadastro_java.model.Usuario;

public interface UsuarioDAOInterface {
	// m�todo a ser implementado
	public void cadastrar(Usuario usuario);
}
