package br.com.cadastro_java.dao;

// importa a interface e a classe Usuario
import br.com.cadastro_java.interfaces.UsuarioDAOInterface;
import br.com.cadastro_java.model.Usuario;
import br.com.cadastro_java.Conexao;

// importa as classes da biblioteca do java
import java.sql.Connection;
import java.sql.*;
import java.sql.PreparedStatement;

public class UsuarioDAO extends Usuario implements UsuarioDAOInterface {
	// atributos
	private Connection conn;
	
	public UsuarioDAO() {
		// TODO Auto-generated constructor stub
		this.conn = new Conexao().ConexaoMySQL();
	}

	@Override
	public void cadastrar(Usuario usuario) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO tb_usuario (nome,email) VALUES (?,?)";
		
		try {
			// declara vari�vel do tipo Preapred Statement
			PreparedStatement stmt = conn.prepareStatement(sql);
			
			// repassa os valores para a consulta SQL
			stmt.setString(1, usuario.getNome());
			stmt.setString(2, usuario.getEmail());
			
			// executa a query
			stmt.execute();
			
			// fecha o objeto
			stmt.close();
		}
		catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}

}
